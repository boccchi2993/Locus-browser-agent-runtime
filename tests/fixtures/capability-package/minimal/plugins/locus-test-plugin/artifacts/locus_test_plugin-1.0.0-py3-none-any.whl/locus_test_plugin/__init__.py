"""Locus synthetic test plugin (TEST fixture only)."""

__version__ = "1.0.0"


def answer():
    """Deterministic smoke-test value for the plugin package boundary."""
    return 42
